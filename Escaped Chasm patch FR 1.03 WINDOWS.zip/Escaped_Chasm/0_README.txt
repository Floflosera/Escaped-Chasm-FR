Pour jouer au jeu, cliquez sur Escaped Chasm. Utilisez les fl�ches directionnelles pour bouger.
Note : Certaines cin�matiques peuvent faire planter le jeu. Si cela arrive, vous devez relancer le jeu. J'ai mis un guide pour vous aider � passer les points de passages plus
rapidement si �a arrive. Le guide et les autres goodies sont situ�s dans le dossier "Extras" en dehors du dossier du jeu.

::::::::CREDITS:::::::::

Escaped Chasm par Temmie Chang

---

Histoire, Illustration et Pixel Art par Temmie Chang
Cin�matiques anim�es (animation, nettoyage, fonds, �dition) par Temmie Chang
sound design des animations par fatbard
Musiques en jeu par Toby Fox
Musique de la cin�matique-TV et sound design (le film qui se joue quand on interagit avec la TV) par James Roach

---

Remerciement sp�ciaux � :
Archeia - a beaucoup aid� pour des questions et ressources RPGMakerMV, a aid� � impl�menter la police d'�criture. (+TDS)
	https://divisionheaven.me/
Yanfly - pour l'utilisation des pluggins Message Core et Core Engine
Stephen Lavelle - pour l'utilisation de bfxr (programme pour faire des effets de sons en jeu qui sonnent bien)
Sumrndmdde - pour avoir utilis� des vid�os tutoriels youtube (elles m'ont beaucoup aid� � apprendre le programme et � rendre �a moins intimidant !)
	sumrndm.site
	tutoriels youtube : https://www.youtube.com/watch?v=IR9y6vco-VQ&list=PLMcr1s5MjsiTky6KB4ML-q_QoBE_ZYJk5

---

Remerciements Sp�ciaux Support Moral !!:
easynam
patrick guschewski
bunnynaut
grind3h
dreamin
jos venti
puppiesandanime
toby

---

Cr�dits Pluggin :
	*Je ne me souviens plus si j'ai utilis� ces plugins au final, mais au cas o� je l'ai fait et que je ne m'en souviens plus/que j'ai oubli� de les enlever/supprimer
	dans le cas o� je ne les ai pas utilis�, j'en ai fait une liste ici !!
	(m�me si je ne les ai pas utilis�, ils ont tous l'air vraiment bien !! Donc vous devriez aller les regarder si vous voulez !)

Yanfly: YEP Core engine, message core
Archeia et TDS
astracat111/markhansaven - Speed up deactivation script

---

System/Engine:
RPGMAKERMV �2015 KADOKAWA CORPORATION./YOJI OJIMA



::::::::SOUS-TITRES DE L'INTRODUCTION:::::::::
(au cas o� c'�tait dur de lire/que �a a �t� trop vie)

	
	Parfois... Quand je ferme les yeux...
	Quand je laisse mon esprit d�river...
	Je peux sentir un monde au au-del� du mien.
	Il est vaste et magnifique.
	... Je peux le voir � travers les yeux d'une fille que j'admire...
	Toutefois...
	Quand je reprends conscience...
	Je me souviens que ce r�ve euphorique n'est pas r�el...
	� mon r�veil, ma connexion � ce monde disparait lentement de ma m�moire.
	... Je ne laisserai pas ce monde m'�chapper.
	Je m'accrocherai � ces fragments de mes r�ves autant que je le peux.
	Peut-�tre que... je ne pourrai jamais vraiment atteindre ce monde...
	Mais peut-�tre qu'un jour
	Je pourrai vraiment devenir la fille que je vois dans cette endroit.

::::::::�PISODE DU DESSIN ANIM�:::::::::
(au cas o� c'�tait dur de lire/que �a a �t� trop vie)


	M�CHANT : Vos efforts sont futiles !
	M�CHANT : Des faibles comme vous sont incapables de me vaincre !
	M�CHANT : Soumettez-vous et acceptez votre destin !
	M�CHANT : Ahahahahaha ! (Rire)
	PROTAGONISTE 1 : Si �a continue, nous sommes fichus !
	PROTAGONISTE 1 : Sauf si...!
	PROTAGONISTE 1 : Je vais utiliser mon pouvoir.
	PROTAGONISTE 2 : Quoi ! Non ! C'est trop dangereux !
	PROGATONISTE 3 : *Hal�te de surprise
	PROTAGONISTE 1 : Il n'y a pas d'autre solution !
	M�CHANT : Peu importe ce que tu essaies, 
	M�CHANT : Tu n'as aucune chance face � moi !
	PROTAGONISTE 1 : �a c'est ce qu'on va voir !
	PROGAGONISTE 1 : (Grognement)
	NARRATEUR : En utilisant le dangereux pouvoir secret,
	NARRATEUR : Nos h�ros auront-ils une chance ?
	NARRATEUR : POUR LE SAVOIR RENDEZ-VOUS DANS LE PROCHAIN �PISODE !

::::::::CIN�MATIQUE DE LA SALLE BONUS:::::::::
(au cas o� c'�tait dur de lire/que �a a �t� trop vie)

	On dirait que le temps est pass�,
	Elle a lentement perdu les souvenirs de sa pr�c�dente vie.
	Toutefois, elle est toujours attir�e par la fille qu'elle � rencontr� en r�ve.
	Mais, peut-�tre pour les mauvaises raisons.
	Peut-�tre qu'un jour elle r�alisera et se souviendra
	De la vraie raison pour laquelle elle est attir�e par elle.
	
::::::::EXTRA:::::::::

Hey ! Merci d'avoir t�l�charger et (peut-�tre) jouer � mon premier jeu rpgmaker !!
J'aurai plus de choses � �crire ici (peut-�tre)
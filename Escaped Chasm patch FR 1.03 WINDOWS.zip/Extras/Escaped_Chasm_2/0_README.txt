Pour jouer au jeu, cliquez sur Escaped Chasm 2.

::::::::CREDITS:::::::::

Escaped Chasm par Temmie Chang
Musiques en jeu par Toby Fox

---

Remerciement sp�ciaux � :
Archeia - a beaucoup aid� pour des questions et ressources RPGMakerMV, a aid� � impl�menter la police d'�criture. (+TDS)
	https://divisionheaven.me/
Yanfly - pour l'utilisation des pluggins Message Core et Core Engine
Stephen Lavelle - pour l'utilisation de bfxr (programme pour faire des effets de sons en jeu qui sonnent bien)
Sumrndmdde - pour avoir utilis� des vid�os tutoriels youtube (elles m'ont beaucoup aid� � apprendre le programme et � rendre �a moins intimidant !)
	sumrndm.site
	tutoriels youtube : https://www.youtube.com/watch?v=IR9y6vco-VQ&list=PLMcr1s5MjsiTky6KB4ML-q_QoBE_ZYJk5

---

Cr�dits Pluggin :
	*Je ne me souviens plus si j'ai utilis� ces plugins au final, mais au cas o� je l'ai fait et que je ne m'en souviens plus/que j'ai oubli� de les enlever/supprimer
	dans le cas o� je ne les ai pas utilis�, j'en ai fait une liste ici !!
	(m�me si je ne les ai pas utilis�, ils ont tous l'air vraiment bien !! Donc vous devriez aller les regarder si vous voulez !)

Yanfly: YEP Core engine, message core
Archeia et TDS
astracat111/markhansaven - Speed up deactivation script


---

System/Engine:
RPGMAKERMV �2015 KADOKAWA CORPORATION./YOJI OJIMA

